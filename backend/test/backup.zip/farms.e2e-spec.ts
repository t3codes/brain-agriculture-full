import request from 'supertest';
import { Test } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import { AppModule } from '../src/app.module';

describe('FarmsController (e2e)', () => {
  let app: INestApplication;
  let token: string;
  let farmId: number;
  let producerId: number;

  beforeAll(async () => {
    const moduleFixture = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ whitelist: true }));
    await app.init();

    // Cria usuário e login para obter token
    await request(app.getHttpServer())
      .post('/api/v1/users/create')
      .send({ email: 'test@example.com', password: '123456' });

    const res = await request(app.getHttpServer())
      .post('/api/v1/users/login')
      .send({ email: 'test@example.com', password: '123456' });

    token = res.body.access_token;

    // Cria produtor para vincular à fazenda
    const producerRes = await request(app.getHttpServer())
      .post('/api/v1/producers/create')
      .set('Authorization', `Bearer ${token}`)
      .send({ name: 'Produtor', cpfOrCnpj: '12345678901' });

    producerId = producerRes.body.id;
  });

  it('/farms/create (POST)', async () => {
    const res = await request(app.getHttpServer())
      .post('/api/v1/farms/create')
      .set('Authorization', `Bearer ${token}`)
      .send({
        name: 'Fazenda 1',
        city: 'Cidade X',
        state: 'Estado Y',
        totalArea: 100,
        arableArea: 80,
        vegetationArea: 20,
        producerId,
      });

    expect(res.status).toBe(201);
    expect(res.body).toHaveProperty('id');
    farmId = res.body.id;
  });

  it('/farms (GET) lista fazendas do produtor', async () => {
    const res = await request(app.getHttpServer())
      .get(`/api/v1/farms?producerId=${producerId}`)
      .set('Authorization', `Bearer ${token}`);

    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  it('/farms/:id (GET)', async () => {
    const res = await request(app.getHttpServer())
      .get(`/api/v1/farms/${farmId}`)
      .set('Authorization', `Bearer ${token}`);

    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('id', farmId);
  });

  it('/farms/update/:id (PUT)', async () => {
    const res = await request(app.getHttpServer())
      .put(`/api/v1/farms/update/${farmId}`)
      .set('Authorization', `Bearer ${token}`)
      .send({ name: 'Fazenda Atualizada' });

    expect(res.status).toBe(200);
    expect(res.body.name).toBe('Fazenda Atualizada');
  });

  it('/farms/delete/:id (DELETE)', async () => {
    const res = await request(app.getHttpServer())
      .delete(`/api/v1/farms/delete/${farmId}`)
      .set('Authorization', `Bearer ${token}`);

    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('success', true);
  });

  afterAll(async () => {
    await app.close();
  });
});

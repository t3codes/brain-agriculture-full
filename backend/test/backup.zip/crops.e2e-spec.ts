import request from 'supertest';
import { Test } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import { AppModule } from '../src/app.module';

describe('CropsController (e2e)', () => {
  let app: INestApplication;
  let token: string;
  let farmId: number;
  let cropId: number;
  let producerId: number;

  beforeAll(async () => {
    const moduleFixture = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ whitelist: true }));
    await app.init();

    // Criação de usuário e login
    await request(app.getHttpServer())
      .post('/api/v1/users/create')
      .send({ email: 'crop@test.com', password: '123456' });

    const res = await request(app.getHttpServer())
      .post('/api/v1/users/login')
      .send({ email: 'crop@test.com', password: '123456' });

    token = res.body.access_token;

    // Criação de produtor
    const producerRes = await request(app.getHttpServer())
      .post('/api/v1/producers/create')
      .set('Authorization', `Bearer ${token}`)
      .send({ name: 'Produtor Crop', cpfOrCnpj: '99988877766' });

    producerId = producerRes.body.id;

    // Criação de fazenda
    const farmRes = await request(app.getHttpServer())
      .post('/api/v1/farms/create')
      .set('Authorization', `Bearer ${token}`)
      .send({
        name: 'Fazenda Crop',
        city: 'Cidade Teste',
        state: 'Estado Teste',
        totalArea: 200,
        arableArea: 150,
        vegetationArea: 50,
        producerId,
      });

    farmId = farmRes.body.id;
  });

  it('/crops/create (POST)', async () => {
    const res = await request(app.getHttpServer())
      .post('/api/v1/crops/create')
      .set('Authorization', `Bearer ${token}`)
      .send([
        {
          name: 'Soja',
          plantedArea: 50,
          farmId,
        },
      ]);

    expect(res.status).toBe(201);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body[0]).toHaveProperty('id');
    cropId = res.body[0].id;
  });

  it('/crops/by-farm/:farmId (GET)', async () => {
    const res = await request(app.getHttpServer())
      .get(`/api/v1/crops/by-farm/${farmId}`)
      .set('Authorization', `Bearer ${token}`);

    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body[0].farmId).toBe(farmId);
  });

  it('/crops/:id (GET)', async () => {
    const res = await request(app.getHttpServer())
      .get(`/api/v1/crops/${cropId}`)
      .set('Authorization', `Bearer ${token}`);

    expect(res.status).toBe(200);
    expect(res.body.id).toBe(cropId);
  });

  it('/crops/:id (PUT)', async () => {
    const res = await request(app.getHttpServer())
      .put(`/api/v1/crops/${cropId}`)
      .set('Authorization', `Bearer ${token}`)
      .send({ name: 'Milho', plantedArea: 60 });

    expect(res.status).toBe(200);
    expect(res.body.name).toBe('Milho');
  });

  it('/crops/:id (DELETE)', async () => {
    const res = await request(app.getHttpServer())
      .delete(`/api/v1/crops/${cropId}`)
      .set('Authorization', `Bearer ${token}`);

    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('success', true);
  });

  afterAll(async () => {
    await app.close();
  });
});

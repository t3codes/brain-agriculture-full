import request from 'supertest';
import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import { AppModule } from '../src/app.module';


describe('ProducersController (e2e)', () => {
  let app: INestApplication;
  let jwtToken: string;
  let createdProducerId: number;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    app.useGlobalPipes(new ValidationPipe());
    await app.init();

    // Criar e logar usuário
    await request(app.getHttpServer()).post('/users/create/accounts').send({
      name: 'Produtor',
      email: 'produtor@email.com',
      password: '123456',
    });

    const login = await request(app.getHttpServer())
      .post('/auth/login')
      .send({ email: 'produtor@email.com', password: '123456' });

    jwtToken = login.body.access_token;
  });

  afterAll(async () => {
    await app.close();
  });

  it('/producers/create (POST)', async () => {
    const response = await request(app.getHttpServer())
      .post('/producers/create')
      .set('Authorization', `Bearer ${jwtToken}`)
      .send({ name: 'Produtor 1', cpfOrCnpj: '12345678909' });

    expect(response.status).toBe(201);
    createdProducerId = response.body.id;
  });

  it('/producers/list (GET)', async () => {
    const response = await request(app.getHttpServer())
      .get('/producers/list')
      .set('Authorization', `Bearer ${jwtToken}`);

    expect(response.status).toBe(200);
    expect(response.body.length).toBeGreaterThan(0);
  });

  it('/producers/:id (GET)', async () => {
    const response = await request(app.getHttpServer())
      .get(`/producers/${createdProducerId}`)
      .set('Authorization', `Bearer ${jwtToken}`);

    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty('id', createdProducerId);
  });
});
